package com.example.khairat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        TextView uN =(TextView) findViewById(R.id.us);
        TextView pwd =(TextView) findViewById(R.id.pass);
        TextView names =(TextView) findViewById(R.id.name);

        SharedPreferences x = getSharedPreferences("dataMode", MODE_PRIVATE);

        uN.setText("Username: " + x.getString("user", ""));
        pwd.setText("Password: " + x.getString("psd", ""));
        names.setText("Full name: " + x.getString("name", ""));


    }

}