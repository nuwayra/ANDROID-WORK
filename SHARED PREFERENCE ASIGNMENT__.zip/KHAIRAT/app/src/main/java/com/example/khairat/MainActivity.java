package com.example.khairat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void save(View v){

        EditText user = (EditText) findViewById(R.id.user);
        EditText pass = (EditText) findViewById(R.id.pass);
        EditText name = (EditText) findViewById(R.id.Name);

        SharedPreferences share = getSharedPreferences("dataMode", MODE_PRIVATE);
        SharedPreferences.Editor edits = share.edit();

        edits.putString("user", user.getText().toString());
        edits.putString("psd", pass.getText().toString());
        edits.putString("name", name.getText().toString());
        edits.commit();

        user.setText("");
        pass.setText("");
        name.setText("");
        user.requestFocus();

        Toast.makeText(MainActivity.this, "Your data has been saved..", Toast.LENGTH_LONG).show();

    }

    public void retieve(View v){
        Intent x = new Intent(MainActivity.this, MainActivity2.class);
        startActivity(x);
    }

    public void clear(View v){

        SharedPreferences share = getSharedPreferences("dataMode", MODE_PRIVATE);
        SharedPreferences.Editor edits = share.edit();

        EditText user = (EditText) findViewById(R.id.user);
        EditText pass = (EditText) findViewById(R.id.pass);
        EditText name = (EditText) findViewById(R.id.Name);

        edits.putString("user", "");
        edits.putString("psd", "");
        edits.putString("name", "");
        edits.commit();

        user.setText("");
        pass.setText("");
        name.setText("");
        user.requestFocus();

        Toast.makeText(MainActivity.this, "Your data has been cleared..", Toast.LENGTH_LONG).show();

    }
}